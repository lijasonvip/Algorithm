package com.bo.search;

public class SequentialSearch {

}
