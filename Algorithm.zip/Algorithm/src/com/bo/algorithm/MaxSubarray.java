package com.bo.algorithm;

public class MaxSubarray {

	//divide and conquer to solve max subarray
	//o(nlgn)  T(n) = 1 when n = 1 or T(n) = 2T(n/2) + o(n).
	public void findMaxSubarray(int[] A, int low, int high){
		if(high == low){
			
		}
		else{
			int mid = (low + high) / 2;
			
		}
	}
}
